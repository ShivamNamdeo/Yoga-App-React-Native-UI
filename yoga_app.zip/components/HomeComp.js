import React from 'react'
import {View,Text,ScrollView} from "react-native";
import {HomeFlex,Header,HeaderButton,HomeHeading,Heading,SubHeading,SearchBox,SearchInput,BottomTabNav,ImageBg} from "../styles/Styles"
import AntDesign from "react-native-vector-icons/AntDesign";
import Ionicons from 'react-native-vector-icons/Ionicons';
import BottomTab  from './BottomTab';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';


function HomeComp({navigation}) {

	const data_list = [
  {
    id: '1',
    title: 'First Item',
    img:"https://api.time.com/wp-content/uploads/2020/03/gym-coronavirus.jpg",
  },
  {
    id: '2',
    title: 'Second Item',
    img:"https://cdn.cnn.com/cnnnext/dam/assets/200414153618-gym-equipment-trnd-restricted-super-tease.jpg",
  },
  {
    id: '3',
    title: 'Third Item',
    img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmtsgQzQkfuN3YFpF9esge3V8HO1G2Q8rC0A&usqp=CAU",
  },
];

	return (



		<HomeFlex>

			<Header>
				<HeaderButton>
					<Ionicons name="menu" size={28} color="#666" />
				</HeaderButton>

				<Heading style={{color:"#fc5203"}}>

					My Yoga
				</Heading>


				<HeaderButton>
					<AntDesign name="message1" size={28} color="#666" />
				</HeaderButton>
			</Header>


			<HomeHeading>
				Stay Healthy With Yoga
			</HomeHeading>


			<SubHeading>
				We have prepared special yoga classes for you so stay home to be healthy
			</SubHeading>


			<SearchBox>
				
				<SearchInput
					placeholder="Search for yoga..."
					
				/>
				<HeaderButton>
					<Ionicons name="search" size={28} color="#666" />
				</HeaderButton>


			</SearchBox>

				<ScrollView showsHorizontalScrollIndicator={false} horizontal={true}>
				{
                		data_list.map((item) => (
                		  
                		  		
                		  		<ImageBg key={item.id} source={{uri:item.img}} imageStyle={{ borderRadius:25}}>	
                		  			<HomeHeading style={{color:"#fff"}} >{item.title} </HomeHeading>
                		  			
								</ImageBg>
                		))
          		}

				</ScrollView>






			<BottomTab navigation={navigation}/>
		



		</HomeFlex>
	)
}

export default HomeComp;