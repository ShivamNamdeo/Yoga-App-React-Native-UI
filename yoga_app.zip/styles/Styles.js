import styled from "styled-components";

export const HomeFlex = styled.View`
	flex:1;
	background-color:#fff;
	padding:25px;
`;


export const Header = styled.View`
	flex-direction:row;
	justify-content:space-between;
	align-items:center;
`;

export const HeaderButton = styled.TouchableOpacity`
	padding:14px;
	border-color:#f0f3f5;
	border-width:2px;
	border-radius:20px;
`;

export const HomeHeading = styled.Text`
	margin-top:5px;
	font-size:30px;
	color:#000;
	width:90%;
	font-family:Poppins-Bold;
`;

export const Heading = styled.Text`

	font-size:20px;
	color:#000;
	font-family:Pacifico-Regular;
`;

export const SubHeading = styled.Text`
	margin-top:1px;
	font-size:12px;
	color:#444;
	font-family:Poppins-Regular;
`;

export const SearchBox = styled.View`
	margin-top:5px;
	flex-direction:row;
	align-items:center;
`;

export const SearchInput = styled.TextInput`
	padding:14px;
	background-color:#f0f3f5;
	flex:1;
	margin-right:10px;
	border-radius:25px;
`;



export const BottomTabNav = styled.View`
	flex-direction:row;
	justify-content:space-between;
	align-items:center;
`;


export const ImageBg = styled.ImageBackground`
	background-color:#666;
	width:300px;
	height:260px;
	align-self:center;
	margin-top:10px;
	border-radius:30px;
	margin-right:16px;
	align-items:flex-end;
`;

export const ProfileImg = styled.Image`
	width:130px;
	height:130px;
	align-self:center;
	border-width:2px;
	border-color:#fc5203;
	border-radius:32px;

`;


export const ProfileName = styled.Text`
	margin-top:10px;
	font-size:20px;
	color:#444;
	font-family:Poppins-Bold;
	text-align:center;
`;

export const Row = styled.View`
	flex-direction:row;
	align-items:center;
	align-self:center;
`;

export const ProfileTab =styled.View`
	flex-direction:row;
	align-items:center;
	justify-content:space-between;
	width:80%;
	align-self:center;
`;


export const HealthRecordBox = styled.View`
	border-width:2px;
	border-color:#f0f3f5;
	border-radius:32px;
	padding:14px;
	margin-top:5px;
`;

export const HealthBottomBox = styled.View`
	border-radius:20px;
	background-color:#f0f3f5;
	padding:20px;
	margin-top:5px;
`;