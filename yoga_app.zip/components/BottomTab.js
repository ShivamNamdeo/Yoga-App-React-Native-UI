import React from 'react'
import {BottomTabNav} from "../styles/Styles"
import AntDesign from "react-native-vector-icons/AntDesign";
import Ionicons from 'react-native-vector-icons/Ionicons';

import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import {View,Text} from "react-native";

function BottomTab({navigation}) {
	return (
			<BottomTabNav>
				<Ionicons name="home" size={28} color="#fc5203" onPress={()=>navigation.navigate("Home")} />
				<AntDesign name="calendar" size={28} color="#666" />
				<MaterialIcons name="collections-bookmark" size={28} color="#666" />

				<AntDesign name="user" size={28} color="#666" onPress={()=>navigation.navigate("Profile")}/>

			</BottomTabNav>
	)
}

export default BottomTab;