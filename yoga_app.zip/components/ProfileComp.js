import React from 'react'
import {View,Text,ScrollView} from "react-native";
import {HomeFlex,Header,HeaderButton,HomeHeading,Heading,HealthRecordBox,ProfileImg,HealthBottomBox,Row,ProfileTab,ProfileName,BottomTabNav,ImageBg} from "../styles/Styles"
import AntDesign from "react-native-vector-icons/AntDesign";
import Ionicons from 'react-native-vector-icons/Ionicons';
import BottomTab  from './BottomTab';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';


function ProfileComp({navigation}) {
	return (



		<HomeFlex>

			<ScrollView showsVerticalScrollIndicator={false}>
			<Header>
				<HeaderButton onPress={()=>navigation.goBack()}>
					<AntDesign name="back" size={28} color="#666" />
				</HeaderButton>

				<Heading style={{fontFamily:"Poppins-Regular"}}> 

					Profile
				</Heading>


				<HeaderButton>
					<Ionicons name="settings-outline" size={28} color="#666" />
				</HeaderButton>
			</Header>

			<ProfileImg source={require("../assets/profile.jpg")} imageStyle={{ borderRadius:25}}/>
			

			<Row>
			<ProfileName>@Dev_Shiv</ProfileName>
			<MaterialIcons name="verified" size={28} color="#fc5203" />
			</Row>

			<ProfileTab>
				<HeaderButton>
					<Heading style={{fontFamily:"Poppins-Regular"}}>Health</Heading>
				</HeaderButton>

				<Heading style={{fontFamily:"Poppins-Regular"}}>Score</Heading>



			</ProfileTab>


			<HealthRecordBox>
				<Header>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:25,fontWeight:"bold"}}>
						Health Recorded
					</Heading>
					<Heading style={{fontFamily:"Poppins-Regular"}}>100% Fit</Heading>
				</Header>


				
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:18,fontWeight:"bold"}}>
						By Month

					</Heading>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}>
						January

					</Heading>

				<Header style={{marginTop:10}}>

					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}> 01 </Heading>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}> 02 </Heading>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}> 03 </Heading>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}> 04 </Heading>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}> 05 </Heading>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}> 06 </Heading>


				</Header>



					

			</HealthRecordBox>


			<Header>


				<HealthBottomBox>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:18,fontWeight:"bold"}}>
						Hearth Rate

					</Heading>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}>
						104

					</Heading>
				</HealthBottomBox>

				<HealthBottomBox>
						<Heading style={{fontFamily:"Poppins-Regular",fontSize:18,fontWeight:"bold"}}>
						Weight

					</Heading>
					<Heading style={{fontFamily:"Poppins-Regular",fontSize:12}}>
						68 KG

					</Heading>
				</HealthBottomBox>


			</Header>








			</ScrollView>




			<BottomTab navigation={navigation}/>
		



		</HomeFlex>
	)
}

export default ProfileComp;